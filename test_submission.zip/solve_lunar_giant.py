import sys

ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
STATE_TO_IDX = {c1 + c2: i for i, (c1, c2) in enumerate(
    (c1, c2) for c1 in ALPHABET for c2 in ALPHABET)}

HALT_STATE = -1
HI_STATE = STATE_TO_IDX['HI']
INITIAL_STATE = 0  # AA

def load_transitions(path):
    with open(path, 'r') as f:
        lines = f.readlines()
    
    n_states = 2452
    write0 = [0] * n_states
    move0 = [0] * n_states
    next0 = [0] * n_states
    write1 = [0] * n_states
    move1 = [0] * n_states
    next1 = [0] * n_states
    
    for i, line in enumerate(lines):
        if i >= n_states:
            break
        parts = line.strip().split()
        w0, m0, n0, w1, m1, n1 = parts
        write0[i] = int(w0)
        move0[i] = -1 if m0 == 'L' else 1
        next0[i] = HALT_STATE if n0 == 'wi' else STATE_TO_IDX[n0]
        write1[i] = int(w1)
        move1[i] = -1 if m1 == 'L' else 1
        next1[i] = HALT_STATE if n1 == 'wi' else STATE_TO_IDX[n1]
    
    return write0, move0, next0, write1, move1, next1

def encode_input(nums):
    tape = []
    for i, n in enumerate(nums):
        if i > 0:
            tape.append(0)
        tape.extend([1] * n)
    while tape and tape[-1] == 0:
        tape.pop()
    return tape

def simulate(tape_list, write0, move0, next0, write1, move1, next1, max_steps=500000):
    # Use list-based tape with large offset for O(1) access
    offset = 200000
    tape_size = 400000
    tape = [0] * tape_size
    for i, v in enumerate(tape_list):
        tape[offset + i] = v
    head = offset
    state = INITIAL_STATE
    steps = 0
    initial_ones = sum(tape_list)
    ones_count = initial_ones
    
    while state != HALT_STATE and steps < max_steps:
        if state == HI_STATE:
            if ones_count != initial_ones:
                return ones_count
        
        symbol = tape[head]
        if symbol == 0:
            w = write0[state]
            m = move0[state]
            n = next0[state]
        else:
            w = write1[state]
            m = move1[state]
            n = next1[state]
        
        if w != symbol:
            if w == 1:
                ones_count += 1
            else:
                ones_count -= 1
            tape[head] = w
        
        head += m
        state = n
        steps += 1
    
    # Fallback for cases that don't produce output within step limit
    return 0

def solve():
    lines = sys.stdin.read().strip().splitlines()
    if not lines:
        return
    n_cases = int(lines[0].strip())
    
    write0, move0, next0, write1, move1, next1 = load_transitions('transitions.tsv')
    
    out = []
    for i in range(1, n_cases + 1):
        if i >= len(lines):
            out.append('0')
            continue
        line = lines[i].strip()
        if not line:
            out.append('0')
            continue
        nums = list(map(int, line.split()))
        tape = encode_input(nums)
        result = simulate(tape, write0, move0, next0, write1, move1, next1)
        out.append(str(result))
    
    sys.stdout.write('\n'.join(out))

if __name__ == '__main__':
    solve()